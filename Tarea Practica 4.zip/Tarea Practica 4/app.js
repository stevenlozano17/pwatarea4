async function cargar(){
 let r=await fetch("tareas.php"); let data=await r.json();
 let lista=document.getElementById("lista"); lista.innerHTML="";
 data.forEach(t=>{
  let li=document.createElement("li");
  li.className="list-group-item d-flex justify-content-between";
  li.innerHTML=`<span>${t.completada?`<s>${t.descripcion}</s>`:t.descripcion}</span>
  <div>
   <button class="btn btn-sm btn-success" onclick="toggle(${t.id})">✔</button>
   <button class="btn btn-sm btn-danger" onclick="eliminar(${t.id})">✖</button>
  </div>`;
  lista.appendChild(li);
 });
}
async function agregar(){ let desc=document.getElementById("nuevaTarea").value;
 if(!desc) return;
 await fetch("tareas.php",{method:"POST",body:new URLSearchParams({descripcion:desc})}); cargar();}
async function toggle(id){ await fetch("tareas.php?toggle="+id); cargar();}
async function eliminar(id){ await fetch("tareas.php?delete="+id); cargar();}
cargar();