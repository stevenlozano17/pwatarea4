<?php
session_start();
require 'db.php';
$message = "";
if($_POST){
 $nombre=$_POST['nombre'];
 $usuario=$_POST['usuario'];
 $password=password_hash($_POST['password'], PASSWORD_BCRYPT);
 $stmt=$pdo->prepare("INSERT INTO usuarios(nombre,usuario,password) VALUES (?,?,?)");
 if($stmt->execute([$nombre,$usuario,$password])) $message="Registro exitoso.";
 else $message="Usuario ya existe.";
}
?>
<!DOCTYPE html><html><head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head><body class="bg-light d-flex justify-content-center align-items-center vh-100">
<div class="card p-4 shadow" style="width:350px;">
<h4>Registrar</h4>
<form method="POST">
<input class="form-control mb-2" name="nombre" placeholder="Nombre" required>
<input class="form-control mb-2" name="usuario" placeholder="Usuario" required>
<input class="form-control mb-3" name="password" type="password" placeholder="Contraseña" required>
<button class="btn btn-primary w-100">Registrar</button>
</form>
<p class="mt-2 text-success"><?php echo $message?></p>
<a href="login.php">Iniciar sesión</a>
</div></body></html>