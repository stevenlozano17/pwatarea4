DROP DATABASE IF EXISTS lista_tareas;
CREATE DATABASE lista_tareas;
USE lista_tareas;

CREATE TABLE usuarios (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nombre VARCHAR(50),
 usuario VARCHAR(50) UNIQUE,
 password VARCHAR(255),
 rol ENUM('admin','user') DEFAULT 'user'
);

INSERT INTO usuarios (nombre, usuario, password, rol) VALUES
('Administrador', 'admin', '$2b$12$PBKsuf9lkk9Kt21K/fANbecvc0Ml6dE7CuMaohVHZMJu631EsRzbu', 'admin'),
('Usuario', 'user', '$2b$12$3Gyn7Ykwgld8TS4NqkCzX./Zcs13Pejh02KUAGZLRjEBxh5KpOSy6', 'user');

CREATE TABLE tareas (
 id INT AUTO_INCREMENT PRIMARY KEY,
 usuario_id INT,
 descripcion VARCHAR(255),
 completada TINYINT DEFAULT 0,
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id)
);