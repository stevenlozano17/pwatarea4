<?php
session_start(); require 'db.php';
if(!isset($_SESSION['user'])) exit;
$user=$_SESSION['user'];
if(isset($_POST['descripcion'])){
 $stmt=$pdo->prepare("INSERT INTO tareas(usuario_id,descripcion) VALUES(?,?)");
 $stmt->execute([$user['id'],$_POST['descripcion']]); exit;
}
if(isset($_GET['toggle'])){ $id=$_GET['toggle'];
 $pdo->query("UPDATE tareas SET completada=1-completada WHERE id=$id AND usuario_id={$user['id']}"); exit; }
if(isset($_GET['delete'])){ $id=$_GET['delete'];
 $pdo->query("DELETE FROM tareas WHERE id=$id AND usuario_id={$user['id']}"); exit; }
$stmt=$pdo->prepare("SELECT * FROM tareas WHERE usuario_id=?");
$stmt->execute([$user['id']]);
echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
?>