<?php
session_start();
if(!isset($_SESSION['user'])){ header("Location: login.php"); exit; }
$user=$_SESSION['user'];
?>
<!DOCTYPE html><html><head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
<script src="app.js" defer></script>
</head><body class="bg-light">
<nav class="navbar navbar-dark bg-dark p-2">
<div class="container d-flex justify-content-between">
<span class="navbar-brand">Hola, <?= $user['nombre']?> (<?= $user['rol']?>)</span>
<a href="usuarios.php" class="btn btn-warning btn-sm <?= $user['rol']!='admin'?'d-none':''?>">Usuarios</a>
<a href="logout.php" class="btn btn-danger btn-sm">Salir</a>
</div></nav>
<div class="container mt-4">
<div class="card p-3 shadow">
<h4>Mis Tareas</h4>
<div class="input-group mb-3">
<input id="nuevaTarea" class="form-control" placeholder="Nueva tarea">
<button onclick="agregar()" class="btn btn-primary">Agregar</button>
</div>
<ul id="lista" class="list-group"></ul>
</div></div></body></html>