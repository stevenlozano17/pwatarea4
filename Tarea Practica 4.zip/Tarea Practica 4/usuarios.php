<?php
session_start(); require 'db.php';
if(!isset($_SESSION['user']) || $_SESSION['user']['rol']!='admin'){ die("Acceso denegado"); }
$usuarios=$pdo->query("SELECT id,nombre,usuario,rol FROM usuarios")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html><html><head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head><body class="bg-light p-4">
<h3>Administración de Usuarios</h3>
<table class="table table-bordered table-striped mt-3">
<tr><th>ID</th><th>Nombre</th><th>Usuario</th><th>Rol</th></tr>
<?php foreach($usuarios as $u): ?>
<tr><td><?= $u['id']?></td><td><?= $u['nombre']?></td><td><?= $u['usuario']?></td><td><?= $u['rol']?></td></tr>
<?php endforeach; ?>
</table>
<a href="index.php" class="btn btn-secondary">Volver</a>
</body></html>