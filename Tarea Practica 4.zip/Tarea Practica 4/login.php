<?php
session_start();
require 'db.php';
$message="";
if($_POST){
 $usuario=$_POST['usuario'];
 $password=$_POST['password'];
 $stmt=$pdo->prepare("SELECT * FROM usuarios WHERE usuario=? LIMIT 1");
 $stmt->execute([$usuario]);
 $user=$stmt->fetch(PDO::FETCH_ASSOC);
 if($user && password_verify($password,$user['password'])){
  $_SESSION['user']=$user;
  header("Location: index.php");exit;
 } else $message="Credenciales inválidas";
}
?>
<!DOCTYPE html><html><head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head><body class="bg-light d-flex justify-content-center align-items-center vh-100">
<div class="card p-4 shadow" style="width:350px;">
<h4>Login</h4>
<form method="POST">
<input class="form-control mb-2" name="usuario" placeholder="Usuario" required>
<input class="form-control mb-3" name="password" type="password" placeholder="Contraseña" required>
<button class="btn btn-primary w-100">Entrar</button>
</form>
<p class="text-danger mt-2"><?php echo $message?></p>
<a href="register.php">Crear cuenta</a>
</div></body></html>